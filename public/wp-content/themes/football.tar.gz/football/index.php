<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <script
        src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="/wp-content/themes/football/css/style.css">
    <script src="/wp-content/themes/football/script/script.js"></script>
</head>
<body>

<!-- header section start -->
<div class="container-fluid header">
    <div class="row site_header">

        <div class="main_menu_control">

            <a class="logo_link" href="#">
                <img src="/wp-content/themes/football/images/logo.png" alt="">
            </a>
            <!--     Humburger button       -->
            <div class="humberger_menu">
                <img class="open_menu" src="/wp-content/themes/football/images/open-menu.png" alt="">
                <img class="close_menu" src="/wp-content/themes/football/images/close-menu.png" alt="">
            </div>

        </div>

        <ul class="menu_control">
            <li class="active"><a href="#">Главная</a></li>
            <li><a href="#">Букмекеры</a></li>
            <li><a href="#">Бонусы</a></li>
            <li><a href="#">Рейтинг БК</a></li>
            <li><a href="#">Mobile БК</a></li>
            <li><a href="#">Ставки</a></li>
            <li><a href="#">Стратегии</a></li>
            <li><a href="#">Справочник</a></li>
            <li><a href="#">О нас</a></li>
        </ul>

        <div class="spacer"></div>

        <div class="search_section">
            <img src="/wp-content/themes/football/images/search.png" alt="">
            <form action="">
                <input type="text" placeholder="Введите слово для поиска...">
            </form>
        </div>

    </div>
</div>
<!-- header section end -->

<!-- Main content start -->
<div class="container content">
    <div class="row">
        <div class="hidden-xs hidden-sm col-md-3 col-lg-3 left_sidebar">
            <ul class="menu_tab">
                <li class="active">Рубрики</li>
                <li>Популярное</li>
            </ul>
            <ul class="rubriky">
                <li>
                    <a href="" class="has_submenu">
                        <span class="link-text">Чемпионаты</span><span class="triangle"></span>
                    </a>
                    <ul class="sub_menu">
                        <li><a href="">Чемпионат Мира</a></li>
                        <li><a href="">Лига Чемпионов</a></li>
                        <li><a href="">Лига Европы</a></li>
                        <li><a href="">Англия</a></li>
                        <li><a href="">Германия</a></li>
                        <li><a href="">Италия</a></li>
                        <li><a href="">Испания</a></li>
                        <li><a href="">Португалия</a></li>
                        <li><a href="">Россия</a></li>
                        <li><a href="">Украина</a></li>
                        <li><a href="">Франция</a></li>
                    </ul>
                </li>
                <li><a href=""><span class="link-text">Ставки на спорт</span><span class="triangle"></span></a></li>
                <li><a href=""><span class="link-text">О букмекерах</span><span class="triangle"></span></a></li>
                <li><a href=""><span class="link-text">Бонусы и акции</span><span class="triangle"></span></a></li>
                <li><a href=""><span class="link-text">Стратегии ставок</span><span class="triangle"></span></a></li>
                <li><a href=""><span class="link-text">Рейтинг БК</span><span class="triangle"></span></a></li>
                <li><a href=""><span class="link-text">Обзор БК</span><span class="triangle"></span></a></li>
                <li><a href=""><span class="link-text">Справочник</span><span class="triangle"></span></a></li>
            </ul>
        </div>
    </div>
</div>
<!-- Main content end -->

</body>
</html>