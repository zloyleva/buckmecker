export class LeftSidebarModule {
    constructor() {
        console.log('LeftSidebarModule is load');

        this.clickOpenMenuHandler();
    }

    clickOpenMenuHandler(){
        $('.has_submenu').off('click').on('click',e=>{
            e.preventDefault();
            console.log('clickOpenMenu');

            this.toglleMenuMethod(e.target);
        });
    }

    toglleMenuMethod(element){
        $(element).closest('li').find('ul.sub_menu').toggle();
        $(element).toggleClass('opens_menu')
    }
}