window.$ = window.jQuery = require('jquery');
console.log('App was loaded');

import {HeaderModule} from './header/header';
import {LeftSidebarModule} from './content/left_sidebar';

$(document).ready(() => {
    console.log('Start...');
    new HeaderModule();
    new LeftSidebarModule();
});